Caesar Cipher Encryption BETA 1.0.0.0

Installation: Just open setup.exe. If you have an older version of this application you must 
              first delete it through Control Panel\Programs and Features.

Use: Type in the key first, and then the text you want to encrypt. As you type, the encryption code 
     will emerge in the ouput box.

DECRYPTION SOFTWARE COMING SOON!

Copyright �  2014 Nguyen Thai Dai Vu