This information is CONFIDENTIAL and should only be made available to individuals chosen by the developer!

Caesar Cipher Encryption BETA 1.0.0.0
This version of the application is not open to the public. It is only available to selected individuals.

Known bugs: If you have text in the input field and delete the key the application may catch an error.

Installation: Just open setup.exe. If you have an older version of this application you must 
              first delete it through Control Panel\Programs and Features.

Use: Type in the key first, and then the text you want to encrypt. As you type, the encryption code will emerge in the ouput box.
     You may change the key [please highlight and type a new one] but do not delete it,
     otherwise the application may catch an error.

Alphabet [sensitive information]: abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456789[space]\/~`!@#$%^&*(),._+{}[]"-=;'[newline]<>|

DECRYPTION SOFTWARE COMING SOON!

Copyright �  2014 Nguyen Thai Dai Vu